import java.util.Scanner;


public class Quiz extends UserName {

    @Override
    public void username() {
        super.username();
    }

    public void multiquiz(){
            username();
            Scanner reader = new Scanner(System.in);

            int numCorrect = 0;

            System.out.println("--------------------------------------------------");
            System.out.println("        Welcome to the Cycling Quiz");
            System.out.println("--------------------------------------------------");

            System.out.println("\nQuestion 1: What dose the Yellow Jersey represent? ");
            System.out.println("a. The Winner of the World Cup");
            System.out.println("b. The Winner Team of The Tour de France");
            System.out.println("c. The Leader and Winner of The Tour de France");
            System.out.println("d. The Youngest competitor of The Tour de France");

            String response = reader.nextLine();
            if(response.equals("c")) {
                System.out.println("Correct!");
                numCorrect++;
            }
            else{
                System.out.println("Incorrect");
            }


            System.out.println("\nQuestion 2: Who has won the most yellow jersey of Tour de France all time ?");
            System.out.println("a. Eddy Merckx");
            System.out.println("b. Peter Sagan");
            System.out.println("c. Chris Froome");
            System.out.println("d. Tadej Pogačar");

            response = reader.nextLine();
            if(response.equals("a")) {
                System.out.println("Correct!");
                numCorrect++;
            }
            else{
                System.out.println("Incorrect");
            }


            System.out.println("\nQuestion 3: What dose the Green Jersey represent?");
            System.out.println("a. The Winner of the World Cup");
            System.out.println("b. The Winner Team");
            System.out.println("c. The Winner of the Sprinter of the Tour de France");
            System.out.println("d. Best Climber of The Tour de France");

            response = reader.nextLine();
            if(response.equals("c")) {
                System.out.println("Correct!");
                numCorrect++;
            }
            else{
                System.out.println("Incorrect");
            }

            System.out.println("\nQuestion 4: Who has won the most of the Green jersey?");
            System.out.println("a. Eddy Merckx");
            System.out.println("b. Peter Sagan");
            System.out.println("c. Mark Cavendish");
            System.out.println("d. Chris Froome");

            response = reader.nextLine();
            if(response.equals("c")) {
                System.out.println("Correct!");
                numCorrect++;
            }
            else{
                System.out.println("Incorrect\n");
            }

            int totalQuestions = 4;
            int score = numCorrect;
            System.out.println("You Scored " + score + " out of 4");

            endOfTheQuiz();
    }

        public void binaryquiz() {
            username();
            Scanner reader = new Scanner(System.in);


            int numCorrect = 0;
            System.out.println("--------------------------------------------------");
            System.out.println("          Welcome to the History Quiz");
            System.out.println("  Answer yes or no to the following questions");
            System.out.println("--------------------------------------------------");

            System.out.println("\nQuestion 1: Was Magna Carta written in 1215? ");
            String response = reader.nextLine();

            if(response.equals("yes")) {
                System.out.println("Correct!");
                numCorrect++;
            }
            else{
                System.out.println("Incorrect");
            }


            System.out.println("\nQuestion 2: Did Harald Hårfagre rule Brittain? ");
            response = reader.nextLine();
            if(response.equals("no")) {
                System.out.println("Correct!");
                numCorrect++;
            }
            else{
                System.out.println("Incorrect");
            }

            System.out.println("\nQuestion 3: Was Norway a founding member of Nato?");
            response = reader.nextLine();
            if (response.equals("yes")) {
                System.out.println("Correct!");
                numCorrect++;
            }
            else {
                System.out.println("Incorrect");
            }

            System.out.println("\nQuestion 4: Is Norway the sole owner of Svalbard?");
            response = reader.nextLine();
            if (response.equals("no")) {
                System.out.println("Correct!\n");
                numCorrect++;
            }
            else {
                System.out.println("Incorrect\n");
            }

            int totalQuestions = 4;
            int score = numCorrect;
            System.out.println("You Scored " + score + " out of 4");

            endOfTheQuiz();
    }

        public void endOfTheQuiz() {
            Scanner user = new Scanner(System.in);
            System.out.println("\nThank you for taking the quiz!\n Would you like to take another quiz?\n");
            int end = 0;
            while (end != 3) {
                quizprint();

                try {
                    end = Integer.parseInt(user.nextLine());
                    switch (end) {
                        case 1 -> multiquiz();
                        case 2 -> binaryquiz();
                        case 3 -> {System.out.println("\nARE you sure want to Quit the Game: If so press 3 again");}
                        default -> {System.out.println("Please enter a valid number");}
                    }
                } catch (NumberFormatException n) {
                    System.out.println("Please enter a valid number");
                }
            }
    }

        public void quizprint() {
            System.out.println("1. Cycling (Multiple Choice Quiz)");
            System.out.println("2. History (Binary Choice Quiz)");
            System.out.println("3. Exit");
    }
}


public class Main {

    public static void main(String[] args) {

        /**
         * All coding is made by myself
         * Source: Programming in Java 5.0,  Inspiration from Kristiania Høyskole lectures.
         */

        Register topic = new Register();
        topic.chooseTopic();
    }
}
USE quizDB;

/*
 * Planning to change from varchar to boolean
 */

CREATE TABLE multichoiceQuiz (
  id INT NOT NULL AUTO_INCREMENT,
  username VARCHAR (30) NOT NULL,
  Question VARCHAR(255),
  Answer1 VARCHAR(45),
  Answer2 VARCHAR(45),
  Answer3 VARCHAR(45),
  Answer4 VARCHAR(45),
  CorrectAnswer VARCHAR(10),
  Round INT,
  PointScore INT,
  PRIMARY KEY (id)
);
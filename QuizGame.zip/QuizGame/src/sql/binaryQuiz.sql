USE quizDB;
CREATE TABLE binaryQuiz(
    id INT NOT NULL AUTO_INCREMENT,
    Username VARCHAR (30) NOT NULL,
    Question VARCHAR(45),
    Option VARCHAR(45),
    PointScore INT,
    PRIMARY KEY (id)
);


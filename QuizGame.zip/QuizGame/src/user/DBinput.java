package user;

public class DBinput extends Person {
    public static DBinput parseUserDB(UserDB userDB) {
        DBinput register = new DBinput();
        register.setId(userDB.id);
        register.setName(userDB.name);
        register.setAnswerA(userDB.answerA);
        register.setAnswerB(userDB.answerB);
        register.setAnswerC(userDB.answerC);
        register.setAnswerD(userDB.answerD);

        return register;
    }
}

package user;

import java.sql.*;
import java.util.ArrayList;

public class JDBCBinary {
    public Object JDBCBinary() {

        //public ArrayList<DBinput> readUsers() {
            ArrayList<DBinput> result = new ArrayList<>();
            String readSql = "SELECT * FROM multichoiceQuiz";
            try {
                Connection con = DriverManager
                        .getConnection("jdbc:mysql://localhost:3306/uniUsers?useSSL=false",
                                "PLEASE YOUR OWN Mysql USERNAME", "PLEASE YOUR OWN Mysql PASSWORD");
                Statement stmt = con.prepareStatement(readSql);
                ResultSet resultSet = stmt.executeQuery(readSql);
            }
            catch (SQLException exception) {
                exception.printStackTrace();
                return null;
            }
            return result;
        }
    }

//}



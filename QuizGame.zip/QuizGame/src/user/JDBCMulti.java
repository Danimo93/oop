package user;
import java.sql.*;
import java.util.ArrayList;

public class JDBCMulti {
    public JDBCMulti() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        }
        catch (ClassNotFoundException exception) {
            exception.printStackTrace();
        }
    }

    public ArrayList<DBinput> readUsers() {
        ArrayList<DBinput> result = new ArrayList<>();
        String readSql = "SELECT * FROM multichoiceQuiz";
        try {Connection con = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/uniUsers?useSSL=false",
                        "PLEASE YOUR OWN Mysql USERNAME",
                        "PLEASE YOUR OWN Mysql PASSWORD");

            Statement stmt = con.prepareStatement(readSql);
            ResultSet resultSet = stmt.executeQuery(readSql);

            /**
             * Planning to change from varchar to boolean
             */


            while (resultSet.next()) {
                UserDB userDB = new UserDB();
                userDB.id = resultSet.getInt("id");
                userDB.name = resultSet.getString("name");
                userDB.answerA = Boolean.parseBoolean(resultSet.getString("answerA"));
                userDB.answerB = Boolean.parseBoolean(resultSet.getString("answerB"));
                userDB.answerC = Boolean.parseBoolean(resultSet.getString("answerC"));
                userDB.answerD = Boolean.parseBoolean(resultSet.getString("answerD"));

                DBinput user = DBinput.parseUserDB(userDB);
                result.add(user);
            }
        }
        catch (SQLException exception) {
            exception.printStackTrace();
            return null;
        }

        return result;
    }
}

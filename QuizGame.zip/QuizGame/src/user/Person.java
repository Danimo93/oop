package user;

public class Person extends JDBCMulti {
    int id;
    String name;
    boolean answerA;
    boolean answerB;
    boolean answerC;
    boolean answerD;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isAnswerA() {
        return answerA;
    }

    public void setAnswerA(boolean answerA) {
        this.answerA = answerA;
    }

    public boolean isAnswerB() {
        return answerB;
    }

    public void setAnswerB(boolean answerB) {
        this.answerB = answerB;
    }

    public boolean isAnswerC() {
        return answerC;
    }

    public void setAnswerC(boolean answerC) {
        this.answerC = answerC;
    }

    public boolean isAnswerD() {
        return answerD;
    }

    public void setAnswerD(boolean answerD) {
        this.answerD = answerD;
    }

}

import java.util.Scanner;

abstract class UserName {
    public void username() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nEnter your name: ");
        String name = scanner.nextLine();
        System.out.println("\n     Hello and Welcome To My Guiz Game " + name + "\n");
    }
}
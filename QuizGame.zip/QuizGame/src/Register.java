import java.util.Scanner;

public class Register extends Quiz {


    public void chooseTopic() {
        Scanner user = new Scanner(System.in);
        System.out.println("\nChoose your Quiz Game");
        int topic = 0;
        while (topic != 3) {
            printTopics();

            try {
                topic = Integer.parseInt(user.nextLine());
                switch (topic) {
                    case 1 -> multiquiz();
                    case 2 -> binaryquiz();
                    case 3 -> {System.out.println("Bye Bye have a amazing day hope you play again");}
                    default -> {System.out.println("Please enter a valid number");}
                }
            }
            catch (NumberFormatException n) {
                System.out.println("Please enter a valid number");
            }
        }
    }

    public void printTopics(){
        System.out.println("1. Cycling (Multiple Choice Quiz)");
        System.out.println("2. History (Binary Choice Quiz)");
        System.out.println("3. Exit");
    }

}


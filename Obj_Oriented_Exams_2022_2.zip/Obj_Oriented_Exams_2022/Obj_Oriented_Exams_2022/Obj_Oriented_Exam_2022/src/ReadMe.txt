Dear reader,

if there is any wrong with the code check out your root username and root password.
It is most likely there the fault lies, otherwise you can check the instructions I made with the SQL files!

Happy reading, and have fun with my Quiz!
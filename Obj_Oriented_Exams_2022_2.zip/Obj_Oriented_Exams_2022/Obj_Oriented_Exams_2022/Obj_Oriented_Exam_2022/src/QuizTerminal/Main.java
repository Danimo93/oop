package QuizTerminal;

public class Main {

    public static void main (String[] args){

        QuizGameTerminal quiz = new QuizGameTerminal();
        quiz.terminal();
    }
}
